import streamlit as st
from streamlit_option_menu import option_menu
from pages.add_items import add_items
from pages.manage_items import manage_items
from pages.invoice_generation import invoice_generation
from pages.reports import reports
from pages.manage_sellers import manage_sellers
from pages.company_settings import company_settings
from utils.db_manager import init_db
from utils.backup_manager import init_backup
from utils.logger import setup_logger

logger = setup_logger()


def main():
    st.set_page_config(
        page_title="Inventory Management System",
        page_icon="📦",
        layout="wide",
        initial_sidebar_state="expanded"
    )

    if not init_db():
        st.error("Failed to initialize database. Please check the logs.")
        return

    try:
        if init_backup():
            logger.info("Backup completed successfully")
        else:
            logger.warning("Backup failed or partially completed")
    except Exception as e:
        logger.error(f"Error during backup: {e}")

    if "logged_in" not in st.session_state:
        st.session_state.logged_in = True  # Simplified for local app usage

    st.markdown(
        """
        <style>
        .nav-link { padding: 0.5rem 1rem !important; margin: 0.2rem 0 !important; }
        .nav-link:hover { background-color: rgba(255, 255, 255, 0.1) !important; }
        .nav-link.active { background-color: #4c85e4 !important; border-radius: 5px !important; }
        .nav-link-div { display: flex !important; align-items: center !important; }
        .nav-link i { margin-right: 0.5rem !important; font-size: 1.1rem !important; }
        .block-container { padding-top: 1rem !important; padding-bottom: 1rem !important; }
        </style>
        """,
        unsafe_allow_html=True,
    )

    with st.sidebar:
        st.markdown("### 🏢 Business Operations")
        selected = option_menu(
            menu_title=None,
            options=[
                "Create Invoice",
                "Add New Items",
                "Inventory Management",
                "Customer Database",
                "Business Analytics",
                "Business Settings",
            ],
            icons=[
                '📄 receipt-cutoff',
                '➕ plus-circle',
                '📦 box-seam',
                '👥 people',
                '📊 graph-up',
                '⚙️ gear',
            ],
            menu_icon=None,
            default_index=0,
            styles={
                "container": {"padding": "0!important", "background-color": "transparent"},
                "icon": {"font-size": "1rem", "margin-right": "0.5rem"},
                "nav-link": {"font-size": "0.9rem", "text-align": "left", "padding": "0.5rem", "border-radius": "5px", "--hover-color": "rgba(255, 255, 255, 0.1)"},
                "nav-link-selected": {"background-color": "#4c85e4", "font-weight": "normal"},
            },
        )

    page_mapping = {
        "Create Invoice": "Invoice Generation",
        "Add New Items": "Add Items",
        "Inventory Management": "Manage Items",
        "Customer Database": "Manage Sellers",
        "Business Analytics": "Reports",
        "Business Settings": "Company Settings",
    }

    if selected == "Create Invoice":
        invoice_generation()
    elif selected == "Add New Items":
        add_items()
    elif selected == "Inventory Management":
        manage_items()
    elif selected == "Customer Database":
        manage_sellers()
    elif selected == "Business Analytics":
        reports()
    elif selected == "Business Settings":
        company_settings()


if __name__ == "__main__":
    main()
