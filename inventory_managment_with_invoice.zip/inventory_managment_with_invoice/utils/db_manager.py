import sqlite3
import os
import logging
from contextlib import contextmanager

logger = logging.getLogger(__name__)

@contextmanager
def get_db_connection():
    conn = sqlite3.connect('inventory.db')
    try:
        conn.execute('PRAGMA foreign_keys = ON')
        conn.execute('PRAGMA journal_mode = WAL')
        conn.execute('PRAGMA synchronous = NORMAL')
        yield conn
    finally:
        conn.close()


def _apply_migrations(conn: sqlite3.Connection) -> None:
    """Apply idempotent migrations to keep DB consistent without data loss."""
    cur = conn.cursor()
    try:
        cur.execute(
            """
            CREATE UNIQUE INDEX IF NOT EXISTS idx_invoices_invoice_number_unique
            ON invoices (invoice_number)
            """
        )
        cur.execute("CREATE INDEX IF NOT EXISTS idx_products_item_code ON products(item_code)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_sellers_name ON sellers(name)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_invoices_seller ON invoices(seller_id)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_transactions_seller ON seller_transactions(seller_id)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_transactions_invoice ON seller_transactions(invoice_id)")

        cur.execute(
            """
            CREATE TRIGGER IF NOT EXISTS trg_products_validate
            BEFORE INSERT ON products
            BEGIN
                SELECT CASE
                    WHEN NEW.quantity < 0 OR NEW.buying_price < 0 OR NEW.selling_price < 0
                        OR NEW.gst_percentage < 0 OR NEW.gst_percentage > 100
                    THEN RAISE(ABORT, 'Invalid product values')
                END;
            END;
            """
        )
        cur.execute(
            """
            CREATE TRIGGER IF NOT EXISTS trg_products_validate_update
            BEFORE UPDATE ON products
            BEGIN
                SELECT CASE
                    WHEN NEW.quantity < 0 OR NEW.buying_price < 0 OR NEW.selling_price < 0
                        OR NEW.gst_percentage < 0 OR NEW.gst_percentage > 100
                    THEN RAISE(ABORT, 'Invalid product values')
                END;
            END;
            """
        )

        cur.execute(
            """
            CREATE TRIGGER IF NOT EXISTS trg_seller_transactions_type
            BEFORE INSERT ON seller_transactions
            BEGIN
                SELECT CASE
                    WHEN NEW.transaction_type NOT IN ('payment','credit')
                    THEN RAISE(ABORT, 'Invalid transaction type')
                END;
            END;
            """
        )

        # Adjust invoices.payment_status to allow 'partial' if table exists
        try:
            cur.execute("PRAGMA table_info(invoices)")
            cols = cur.fetchall()
            if cols:
                # Create a shadow table with updated CHECK constraint if needed
                cur.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='invoices'")
                create_sql_row = cur.fetchone()
                if create_sql_row and 'CHECK' in create_sql_row[0] and "'partial'" not in create_sql_row[0]:
                    logger.info("Migrating invoices table to allow 'partial' payment_status")
                    cur.execute("BEGIN")
                    cur.execute("ALTER TABLE invoices RENAME TO invoices_old")
                    cur.execute(
                        """
                        CREATE TABLE invoices (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            invoice_data TEXT,
                            total_amount REAL,
                            date TEXT,
                            seller_id INTEGER,
                            payment_status TEXT CHECK (payment_status IN ('paid','credit','partial')) DEFAULT 'paid',
                            invoice_number TEXT UNIQUE,
                            FOREIGN KEY(seller_id) REFERENCES sellers(id)
                        )
                        """
                    )
                    cur.execute(
                        """
                        INSERT INTO invoices (id, invoice_data, total_amount, date, seller_id, payment_status, invoice_number)
                        SELECT id, invoice_data, total_amount, date, seller_id, payment_status, invoice_number FROM invoices_old
                        """
                    )
                    cur.execute("DROP TABLE invoices_old")
                    cur.execute("COMMIT")
        except Exception as mig_e:
            logger.warning(f"Skipping payment_status migration: {mig_e}")

        conn.commit()
    except Exception as e:
        logger.error(f"Error applying migrations: {e}")
        conn.rollback()


def init_db():
    try:
        schema_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'schema.sql')
        with open(schema_path, 'r') as f:
            schema = f.read()

        with get_db_connection() as conn:
            conn.executescript(schema)
            _apply_migrations(conn)
            logger.info("Database schema initialized successfully")
            return True
    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        return False


def ensure_company_details_exist():
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='company_details'
                """
            )
            if not cursor.fetchone():
                init_db()

            cursor.execute("SELECT COUNT(*) FROM company_details")
            if cursor.fetchone()[0] == 0:
                cursor.execute(
                    """
                    INSERT INTO company_details (
                        name, address, city, state, state_code, gstin, 
                        phone, email, bank_name, bank_account, bank_ifsc, 
                        bank_branch, jurisdiction
                    ) VALUES (
                        'GANANATH ENTERPRISES',
                        'New Colony',
                        'Rayagada',
                        'Odisha',
                        '21',
                        'XXX1933884',
                        '',
                        '',
                        'HDFC BANK',
                        '50200055243922',
                        'HDFC0000640',
                        'HDFC BANK NAYAPALLI BRANCH',
                        'BHUBANESWAR'
                    )
                    """
                )
                conn.commit()
            return True
    except Exception as e:
        logger.error(f"Error ensuring company details: {e}")
        return False 