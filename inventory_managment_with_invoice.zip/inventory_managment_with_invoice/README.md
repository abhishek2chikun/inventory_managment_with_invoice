# Inventory Management with Invoices (Streamlit)

A simple, robust, single-file SQLite-based inventory and invoicing system built with Streamlit. It supports item management, bulk imports, invoice generation (paid, partial, credit), seller due tracking with history, analytics dashboards, and automated local/Google Drive backups.

## Highlights
- Robust SQLite schema with foreign keys, unique invoice numbers, indexes, and triggers
- Strict data validation and safer connection defaults (WAL, foreign_keys=ON)
- Clean separation of concerns: pages (UI), utils (DB, logging, backup, PDF)
- Automatic backup on app start (local + Google Drive)
- Partial payments: split of payment and credit recorded atomically

---

## Features
- Add Products
  - Add single product with GST and computed buying price (incl. GST)
  - Bulk upload via CSV/Excel with column mapping and inline editing
  - Add multiple items quickly by fixing company/category
  - Data validation: non-negative prices/quantities, GST in [0,100]

- Manage Inventory
  - Filter by company/category/item
  - Inline edit items (name, code, prices, quantity, GST, date)
  - Delete selected products

- Invoice Generation
  - Seller selection from history or add new on-the-fly
  - Product filters and stock-aware item selection
  - Inline editing of invoice items (quantity, price, discounts, GST)
  - Accurate totals: taxable subtotal, GST amount, final amount
  - Payment statuses: paid, partial, credit
    - paid: records full payment
    - partial: records a payment for the entered amount and credit for the remainder
    - credit: records full credit
  - PDF preview and generation with company details and bank info
  - Auto-increment-like invoice numbers (INV0001, ...), resilient to deletions

- Manage Sellers (Customers)
  - Add/edit seller details (name, address, phone, GSTIN)
  - View sellers with summary: invoices, sales, payments, outstanding
  - Record payments against seller (validated by pending balance)
  - View per-seller invoice history and transactions

- Reports & Analytics
  - Executive summary with period filters
  - Daily sales trend with moving averages
  - Top products by revenue and quantity
  - Basic customer RFM segmentation (Champions, Loyal, Regular, New/Inactive)
  - Inventory insights: stock value by category, low-stock alerts

- Backups
  - Local rotating backups in `backups/`
  - Optional Google Drive upload to `InventoryBackups` folder

---

## Project Structure
- `main.py`: App entry, navigation, init DB, run backup
- `pages/`
  - `add_items.py`: Add single/bulk items, combine items
  - `manage_items.py`: Filter/edit/delete products
  - `invoice_generation.py`: Build invoice, partial/credit/paid, save and adjust stock, PDF preview
  - `manage_sellers.py`: Seller CRUD, dues, transactions, invoice search
  - `reports.py`: Dashboards and analytics
  - `company_settings.py`: Company and bank details
- `utils/`
  - `db_manager.py`: Connection, schema init, migrations, safe pragmas
  - `backup_manager.py`: Local + Google Drive backup
  - `logger.py`: File + console logger (no duplicate handlers)
  - `pdf_generator.py`: Placeholder class for future PDF refactor
  - `validators.py`: Basic validation helpers
- `schema.sql`: Canonical DB schema, indexes, triggers, defaults
- `inventory.db`: SQLite database (created/updated on first run)
- `invoices/`: Generated invoice PDFs
- `backups/`: Local DB backups

---

## Database Design

Tables
- `products`
  - Unique keys: `(company, category, item_name)` and `item_code`
  - Triggers enforce: non-negative `buying_price`, `selling_price`, `quantity`; `gst_percentage` in [0,100]
- `sellers`
  - Unique `(name, phone)`; maintains `total_credit` (auto-updated by trigger)
- `invoices`
  - `invoice_number` UNIQUE, `payment_status` in {paid, credit, partial}
- `seller_transactions`
  - `transaction_type` in {payment, credit}
  - Trigger `update_seller_credit` adjusts `sellers.total_credit` on every insert: +credit, -payment
- `company_details`
  - Single-record table for invoice header/footer and bank details

Indexes
- `products(item_code)`, `sellers(name)`, `invoices(invoice_number) UNIQUE`, `invoices(seller_id)`, `seller_transactions(seller_id)`, `seller_transactions(invoice_id)`

Migrations
- On startup, migrations ensure indexes, triggers, and that `invoices.payment_status` supports `partial`.

Connection
- `PRAGMA foreign_keys=ON`, `PRAGMA journal_mode=WAL`, `PRAGMA synchronous=NORMAL` per connection

---

## Validation & Business Rules
- Product insert/update fails if values invalid (trigger-level enforcement)
- Invoice item add prevents exceeding available stock (checks both DB and items in current invoice)
- Seller payment entry prevents over-payment
- Partial payment on invoice save:
  - Records a `payment` transaction for the paid amount (if > 0)
  - Records a `credit` transaction for the remainder
  - Trigger updates `sellers.total_credit`

---

## Setup

Prerequisites
- Python 3.10+
- Tesseract (optional, for OCR during bulk add from images)
- Google API credentials (optional, for Drive backup): place `credentials.json` in project root

Install
```bash
python -m venv .venv
. .venv/Scripts/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Run
```bash
streamlit run main.py
```

On first run
- DB is initialized via `schema.sql` then migrations
- Company details are inserted if missing (edit later in Business Settings)
- A local backup is created; if Google credentials exist, also uploaded to Drive

---

## Backups
- Local: `backups/inventory_YYYYMMDD_HHMMSS.db` (keeps last 5 by default in `utils/backup_manager.py`)
- Google Drive: uploads to `InventoryBackups` (keeps last 10)
- To enable Drive uploads:
  1. Create OAuth credentials and save `credentials.json` in the project root
  2. First run will prompt auth and save `token.pickle`

---

## User Guide

1) Add Items
- Use Add New Items → Single/Bulk/Combine tab
- Validate GST and prices; duplicate checks for name/code combos

2) Manage Inventory
- Filter, inline-edit, save; delete selected products

3) Generate Invoice
- Choose seller or add new
- Filter products; select items (stock-aware)
- Edit quantities/price/discount/GST; save changes
- Choose Payment Status:
  - Paid: records full payment
  - Credit: records full credit
  - Partial: enter partial amount paid; remaining is recorded as credit
- Generate and Save Invoice
  - Updates inventory quantities
  - Writes invoice, transactions, and updates seller credit via trigger
  - PDF is generated to preview/download (folder `invoices/`)

4) Manage Sellers
- Add/edit sellers
- View list with Total Sales, Total Payments, Outstanding Due (`total_credit`)
- Record standalone payments
- View transactions and invoices per seller; search by invoice number

5) Reports
- Use sidebar date filters
- Review executive summary, trends, top products, customer segmentation, and inventory insights

6) Business Settings
- Update company, GST, and bank details (reflected on invoices)

---

## Configuration
- `requirements.txt`: pinned dependencies
- `config.py`: basic constants (paths, company info) for future consolidation
- Logging to `logs/app_YYYYMMDD.log`

---

## Security & Data Integrity
- SQLite FK enforced; WAL mode for better concurrency
- Triggers for credit and product validations ensure consistency even outside the app
- Parameterized queries to avoid SQL injection

---

## Troubleshooting
- DB locked: ensure single writer; WAL should mitigate. Retry after closing other sessions
- Google backup fails: verify `credentials.json` and network access
- PDF layout issues: adjust column widths in `invoice_generation.generate_pdf`
- Tesseract/OCR: ensure Tesseract installed and in PATH; image extraction is best-effort

---

## Roadmap
- Move PDF generation to `utils/pdf_generator.PDFGenerator`
- Add unit tests for invoice numbering and triggers
- Add per-item stock valuation and profit reports
- Add role-based auth and a real login flow
- REST API for integrations and mobile apps

---

## License
MIT (or your preferred license). 